#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* next;
};

Node* head = 0;

void insertAtBeginning(){
    int n;
    cout<<"enter value: ";
    cin>>n;
    Node* newnode = new Node{n, head};//next pointer of new node points to head 
    head = newnode;//head now ppoints to the newnode that is now inserted in the started
}

void insertAtEnd(){
    int n;
    cout<<"enter value: ";
    cin>>n;
    Node* newnode = new Node{n,0};//0 becasue this node will be the last node
    if (head == 0){//if the list is empty the head pointer points to this node 
        head = newnode;
        return;
    }
    Node* temp = head;//making a temporary node and that = head and then we traverse till end and then we replace the temp with actual node
    while(temp->next !=0){//traversing through the list till end
        temp = temp->next;//moving / traversing in the list
    }//loop ends when we find the last node and the last node = temp
    temp->next = newnode;//hence we link the last node to the new node 
}

void insertAfteraNode(){//key - the value in list after which we will insert our newnode
    //checkinh if list is empty
    int n,key;
    cout<<"enter value: ";
    cin>>n;
    cout<<"enter key: ";
    cin>>key;

    if(head == 0){
        cout<<"list is empty";
        return ;
    }
    //making a temp node
    Node* temp = head;

    //searching for key
    while(temp != 0 && temp->data != key){// loop will stop immediately if key is not found and we read the end and temp == nullptr so that temp does not try to access nullptr data which will cause segmentation fault
        temp=temp->next;
    }
    //checking since if key not found from aboove while loop and end with temp = nullptr 
    if(temp == 0){
        cout<<"key not found"<<endl;
        return;
    }

    //creating new node to be inserted if we found the key
    Node* newNode = new Node{n, 0};

    //inserting after the key node

    newNode->next = temp->next;// temp next currently points to the node after the key node so we assign that valur to it 
    temp->next = newNode; // tempnext points to the newnode  
}

void insertBeforeaNode(){

    int n,key;
    cout<<"enter value: ";
    cin>>n;
    cout<<"enter key: ";
    cin>>key;

    if(head==0){
        cout<<"list is empty"<<endl;
        return;
    }
    //if the key is at the head
    if(head->data == key){
        Node* newNode = new Node{n,head};
        head = newNode;
        return;
    }
    Node* prev = head;
    Node* current = head->next;
    //we have to insert a node in between thse prev and current

    //traversing
    while(current != 0 && current->data != key){
        prev = current;
        current = current->next;
    }

    if(current == 0){
        cout<<"key not found"<<endl;
        return;
    }
    //insert newNode before current
    Node* newNode = new Node{n,current};
    prev->next = newNode;
}

void deleteFromBeginning(){
    if(head == 0){
        return;
    }
    Node* temp = head;//saving the head pointer just in case
    head = head->next;//second node becomes new head
    delete temp;//free memory of old head node
}

void deleteFromEnd(){
    //check if list is empty or not
    if(head == 0){
        return;
    }
    if(head->next == 0){//if the node to which head is pointing ... its next pointer is null then we delete that head
        delete head;
        head == 0;//and then assign null value making it the end pointer
        return;
    }
}

void deleteAtPosition(){
    int key;
    cout<<"enter key: ";
    cin>>key;

    if(head == 0){
        return;
    }
    if(head->data == key){
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }
}

void search(){

    int key;
    cout<<"enter key: ";
    cin>>key;

    Node* temp = head;
    int pos = 1;
    while (temp != 0){
        if (temp->data){
            cout << "node found at position: "<<pos<<endl;
            return ;
        }
        temp = temp->next;
        pos++;
    }
    cout<<"node not found."<<endl;
}

void display(){
    Node* temp = head;

    if (temp == 0){
        cout<<"list is empty"<<endl;
        return;
    }
    while (temp != 0){
        cout<<temp->data<<" -> ";
        temp = temp->next;
    }
}

int main(){
    int choice,  value, key;
    
    while(true){
        cout<<"choose from below-----"<<endl;
        cout<<"1. insert at beginning"<<endl;
        cout<<"2. insert at end"<<endl;
        cout<<"3. insert after a node"<<endl;
        cout<<"4. insert before a node"<<endl;
        cout<<"5. delete from beginning"<<endl;
        cout<<"6. delete from end"<<endl;
        cout<<"7. delete specific node"<<endl;
        cout<<"8. search for a node"<<endl;
        cout<<"9. display all nodes"<<endl;
        cout<<"10. exit"<<endl;
        cout<<endl;
        cout<<"enter choice: "<<endl;
        cin>>choice;

        switch (choice) {
            case 1:
            insertAtBeginning();
            break;

            case 2:
            insertAtEnd();
            break;

            case 3:
            insertAfteraNode();
            break;

            case 4:
            insertBeforeaNode();
            break;

            case 5:
            deleteFromBeginning();
            break;

            case 6:
            deleteFromEnd();
            break;

            case 7:
            
            deleteAtPosition();
            break;

            case 8:
            search();
            break;

            case 9:
            display();
            break;

            case 10:
            exit(0);

            default:
            cout<<"invalid choice"<<endl;
        }
    }
}
