#include <iostream>
#include <string>
using namespace std;
#define max 100

char stack[max];
int top = -1;
void push(char c){
    if (top == max - 1) {
        cout << "Stack Overflow\n";
        return;
    }
    stack[++top] = c;
}

char pop(){
    int item;
    if(top == -1){
        cout<<"underflow"<<endl;
        return 0;
    }
    return stack[top--];
}
int main(){
    string str = "DataStructure";

    //push all characters onto the stack
    for(int i = 0; i< str.length();i++ ){
        push(str[i]);
    }
    //pop and print
    
    cout << "Original String: " << str << endl;
    cout << "Reversed String: ";
    while (top != -1) {
        cout<<pop();
    }
    
}