//implementation of stack operations using arrays
#include <iostream>
using namespace std;
#define N 5
int stack[N];
int top = -1;

void push(){
    int x;
    cout<<"enter data: ";
    cin>>x;
    cout<<endl;

    if(top == N-1){
        cout<<"overflow"<<endl;
    }
    else{
        top++;
        stack [top] = x;
    }
}
void pop(){
    int item;
    if(top == -1){
        cout<<"underflow"<<endl;
    }
    else{
        item = stack[top];
        cout<<"the popped item is: "<<item<<endl;
        top--;
    }
}
bool isempty(){
    if(top == -1){
        cout<<"the stack is empty"<<endl;
        return true;
    }
    else{
        return false;
    }
}

bool isfull(){
    if(top == N-1){
        cout<<"the stack is full"<<endl;
        return true;
    }
    else{
        return false;
    }
}

void display(){
    for(int i=top; i>=0; i--){
        cout<<stack[i]<<" ";
    }
    cout<<endl;
}

void peek(){
    
    if (isempty()){
    }
    else{
        cout<<stack[top]<<endl;
    }
}

int main(){
    int choice;

    while(true){
        cout<<"\n1) Push"<<endl;
        cout<<"2) Pop"<<endl;
        cout<<"3) isempty"<<endl;
        cout<<"4) isfull"<<endl;
        cout<<"5) display"<<endl;
        cout<<"6) Peek"<<endl;
        cout<<"7) Exit"<<endl;
        cout<<"\nEnter choice: ";

        cin>>choice;
        cout<<endl;

        switch(choice){
            case 1:
                push();
                break;
            case 2:
                pop();
                break;
            case 3:
                isempty();
                break;
            case 4:
                isfull();
                break;
            case 5:
                display();
                break;
            case 6:
                peek();
                break;
            case 7:
                return 0;
            default:
                cout<<"Invalid choice"<<endl;
        }
    }



}
