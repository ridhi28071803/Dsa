//concatenate 1 string to another
#include <iostream>
#include <string>
using namespace std;

int main(){
    string str1 = "Ridhi ";
    string str2 = "batra";

    str1 += str2;

    cout<<"the concatenated string is: "<<str1<<endl;
}